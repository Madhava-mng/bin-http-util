# bin-http-util

simple tool for taggle post request.

```ruby
$ http-post -d '{"user":"pass"}' https://hostname/post
```
